import csv
from time import time
import Matrix
import random

def measure_execution_time(matrix_size, num_runs):
    A = [[random.random() for _ in range(matrix_size)] for _ in range(matrix_size)]
    B = [[random.random() for _ in range(matrix_size)] for _ in range(matrix_size)]

    execution_times = []
    for _ in range(num_runs):
        start = time()
        Matrix.matrix_multiply(A, B)
        end = time()
        execution_time = end - start
        execution_times.append(execution_time)

    average_execution_time = sum(execution_times) / num_runs
    return average_execution_time, execution_times

matrix_sizes = [32, 64, 128, 256, 512]
num_runs = 32

all_execution_times = []

for size in matrix_sizes:
    average_time, times = measure_execution_time(size, num_runs)
    all_execution_times.append(times)

    print(f"Matrix Size: {size}x{size}, Average Execution Time: {average_time:.6f} seconds")

with open('execution_times.csv', mode='w', newline='') as file:
    writer = csv.writer(file)
    writer.writerow(['Matrix Size', 'Execution Time (seconds)'])
    
    for size, times in zip(matrix_sizes, all_execution_times):
        for time in times:
            writer.writerow([f"{size}", time])
