#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>

#define NUM_SIZES 5
int sizes[NUM_SIZES] = {32,64, 128, 256, 512};
#define NUM_RUNS 32

double a[2048][2048];
double b[2048][2048];
double c[2048][2048];

struct timeval start, stop;
double execution_times[NUM_SIZES][NUM_RUNS];

int main() {
    FILE *outputFile;
    outputFile = fopen("execution_times_c.csv", "w");

    if (outputFile == NULL) {
        perror("Error opening the file.");
        return 1;
    }

    fprintf(outputFile, "Matrix Size,Execution Time (seconds)\n");

    for (int size_index = 0; size_index < NUM_SIZES; ++size_index) {
        int size = sizes[size_index];

        for (int run = 0; run < NUM_RUNS; ++run) {
            for (int i = 0; i < size; ++i) {
                for (int j = 0; j < size; ++j) {
                    a[i][j] = (double)rand() / RAND_MAX;
                    b[i][j] = (double)rand() / RAND_MAX;
                    c[i][j] = 0;
                }
            }

            gettimeofday(&start, NULL);

            for (int i = 0; i < size; ++i) {
                for (int j = 0; j < size; ++j) {
                    for (int k = 0; k < size; ++k) {
                        c[i][j] = a[i][k] * b[k][j];
                    }
                }
            }

            gettimeofday(&stop, NULL);

            double diff = stop.tv_sec - start.tv_sec + 1e-6 * (stop.tv_usec - start.tv_usec);
            execution_times[size_index][run] = diff;

            fprintf(outputFile, "%d,%f\n", size, diff);
        }
    }

    fclose(outputFile);

    return 0;
}
